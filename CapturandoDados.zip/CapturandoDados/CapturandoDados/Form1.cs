﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapturandoDados
{
    public partial class FrmDados : Form
    {
        public FrmDados()
        {
            InitializeComponent();
        }

        private void txtTexto_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblBoleano_Click(object sender, EventArgs e)
        {

        }

        private void btnEnviar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Informações enviadas!");

        }

        private void FrmDados_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Abriu formulário!");
        }

        private void txtInteiro_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Alterou o Texto!");
        }

        private void lblTexto_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Clicou na label!");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Texto removido!");
        }
    }
}

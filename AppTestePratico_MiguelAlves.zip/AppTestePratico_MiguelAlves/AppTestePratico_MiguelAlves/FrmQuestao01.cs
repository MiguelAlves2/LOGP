﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppTestePratico_MiguelAlves
{
    public partial class FrmQuestao01 : Form
    {
        public FrmQuestao01()
        {
            InitializeComponent();
        }

        private void btnComprar_Click(object sender, EventArgs e)
        {
            float Paes = float.Parse(txtPao.Text);
            float Broa = float.Parse(txtBroa.Text);
            float resultado;

            resultado = (Paes * 0.12f) + (Broa * 1.50f);

            lblResultado.Text = "R$" + resultado;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppTestePratico_MiguelAlves
{
    public partial class FrmQuestao02 : Form
    {
        public FrmQuestao02()
        {
            InitializeComponent();
        }

        private void btnComprar_Click(object sender, EventArgs e)
        {
            float CamisaP = int.Parse(txtCamisaP.Text);
            float CamisaM = int.Parse(txtCamisaM.Text);
            float CamisaG = int.Parse(txtCamisaG.Text);
            float resultado;

            resultado = (CamisaP * 12) + (CamisaM * 14) + (CamisaG * 22);

            lblResultado.Text = "R$" + resultado;
        }
    }
}

﻿namespace AppTestePratico_MiguelAlves
{
    partial class FrmQuestao02
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmQuestao02));
            this.lblLoja = new System.Windows.Forms.Label();
            this.lblCamisaP = new System.Windows.Forms.Label();
            this.txtCamisaP = new System.Windows.Forms.TextBox();
            this.lblCamisaM = new System.Windows.Forms.Label();
            this.txtCamisaM = new System.Windows.Forms.TextBox();
            this.lblCamisaG = new System.Windows.Forms.Label();
            this.txtCamisaG = new System.Windows.Forms.TextBox();
            this.btnComprar = new System.Windows.Forms.Button();
            this.lblLegenda = new System.Windows.Forms.Label();
            this.lblResultado = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblLoja
            // 
            this.lblLoja.AutoSize = true;
            this.lblLoja.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLoja.Location = new System.Drawing.Point(149, 28);
            this.lblLoja.Name = "lblLoja";
            this.lblLoja.Size = new System.Drawing.Size(233, 37);
            this.lblLoja.TabIndex = 0;
            this.lblLoja.Text = "Loja do Coroa";
            // 
            // lblCamisaP
            // 
            this.lblCamisaP.AutoSize = true;
            this.lblCamisaP.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCamisaP.Location = new System.Drawing.Point(43, 95);
            this.lblCamisaP.Name = "lblCamisaP";
            this.lblCamisaP.Size = new System.Drawing.Size(402, 24);
            this.lblCamisaP.TabIndex = 1;
            this.lblCamisaP.Text = "Digite a quantidade de camisas P que deseja...";
            // 
            // txtCamisaP
            // 
            this.txtCamisaP.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCamisaP.Location = new System.Drawing.Point(48, 129);
            this.txtCamisaP.Name = "txtCamisaP";
            this.txtCamisaP.Size = new System.Drawing.Size(405, 31);
            this.txtCamisaP.TabIndex = 2;
            // 
            // lblCamisaM
            // 
            this.lblCamisaM.AutoSize = true;
            this.lblCamisaM.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCamisaM.Location = new System.Drawing.Point(43, 176);
            this.lblCamisaM.Name = "lblCamisaM";
            this.lblCamisaM.Size = new System.Drawing.Size(406, 24);
            this.lblCamisaM.TabIndex = 3;
            this.lblCamisaM.Text = "Digite a quantidade de camisas M que deseja...";
            // 
            // txtCamisaM
            // 
            this.txtCamisaM.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCamisaM.Location = new System.Drawing.Point(48, 212);
            this.txtCamisaM.Name = "txtCamisaM";
            this.txtCamisaM.Size = new System.Drawing.Size(405, 31);
            this.txtCamisaM.TabIndex = 4;
            // 
            // lblCamisaG
            // 
            this.lblCamisaG.AutoSize = true;
            this.lblCamisaG.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCamisaG.Location = new System.Drawing.Point(47, 263);
            this.lblCamisaG.Name = "lblCamisaG";
            this.lblCamisaG.Size = new System.Drawing.Size(404, 24);
            this.lblCamisaG.TabIndex = 5;
            this.lblCamisaG.Text = "Digite a quantidade de camisas G que deseja...";
            // 
            // txtCamisaG
            // 
            this.txtCamisaG.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCamisaG.Location = new System.Drawing.Point(49, 300);
            this.txtCamisaG.Name = "txtCamisaG";
            this.txtCamisaG.Size = new System.Drawing.Size(405, 31);
            this.txtCamisaG.TabIndex = 6;
            // 
            // btnComprar
            // 
            this.btnComprar.BackColor = System.Drawing.Color.Turquoise;
            this.btnComprar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnComprar.Location = new System.Drawing.Point(57, 91);
            this.btnComprar.Name = "btnComprar";
            this.btnComprar.Size = new System.Drawing.Size(219, 86);
            this.btnComprar.TabIndex = 7;
            this.btnComprar.Text = "Comprar";
            this.btnComprar.UseVisualStyleBackColor = false;
            this.btnComprar.Click += new System.EventHandler(this.btnComprar_Click);
            // 
            // lblLegenda
            // 
            this.lblLegenda.AutoSize = true;
            this.lblLegenda.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLegenda.Location = new System.Drawing.Point(72, 215);
            this.lblLegenda.Name = "lblLegenda";
            this.lblLegenda.Size = new System.Drawing.Size(109, 20);
            this.lblLegenda.TabIndex = 8;
            this.lblLegenda.Text = "Valor a Pagar:";
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado.Location = new System.Drawing.Point(187, 215);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(35, 20);
            this.lblResultado.TabIndex = 9;
            this.lblResultado.Text = "R$-";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.panel1.Controls.Add(this.lblResultado);
            this.panel1.Controls.Add(this.lblLegenda);
            this.panel1.Controls.Add(this.btnComprar);
            this.panel1.Location = new System.Drawing.Point(477, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(324, 453);
            this.panel1.TabIndex = 10;
            // 
            // FrmQuestao02
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleGreen;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.txtCamisaG);
            this.Controls.Add(this.lblCamisaG);
            this.Controls.Add(this.txtCamisaM);
            this.Controls.Add(this.lblCamisaM);
            this.Controls.Add(this.txtCamisaP);
            this.Controls.Add(this.lblCamisaP);
            this.Controls.Add(this.lblLoja);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmQuestao02";
            this.Text = "Loja do Coroa";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblLoja;
        private System.Windows.Forms.Label lblCamisaP;
        private System.Windows.Forms.TextBox txtCamisaP;
        private System.Windows.Forms.Label lblCamisaM;
        private System.Windows.Forms.TextBox txtCamisaM;
        private System.Windows.Forms.Label lblCamisaG;
        private System.Windows.Forms.TextBox txtCamisaG;
        private System.Windows.Forms.Button btnComprar;
        private System.Windows.Forms.Label lblLegenda;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.Panel panel1;
    }
}
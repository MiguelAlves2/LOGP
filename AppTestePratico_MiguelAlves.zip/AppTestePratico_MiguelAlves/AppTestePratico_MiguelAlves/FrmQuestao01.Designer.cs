﻿namespace AppTestePratico_MiguelAlves
{
    partial class FrmQuestao01
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmQuestao01));
            this.lblPadaria = new System.Windows.Forms.Label();
            this.txtPao = new System.Windows.Forms.TextBox();
            this.lblPao = new System.Windows.Forms.Label();
            this.pnlPadaria = new System.Windows.Forms.Panel();
            this.lblBroa = new System.Windows.Forms.Label();
            this.txtBroa = new System.Windows.Forms.TextBox();
            this.btnComprar = new System.Windows.Forms.Button();
            this.lblLegenda = new System.Windows.Forms.Label();
            this.lblResultado = new System.Windows.Forms.Label();
            this.pnlPadaria.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblPadaria
            // 
            this.lblPadaria.AutoSize = true;
            this.lblPadaria.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPadaria.Location = new System.Drawing.Point(272, 35);
            this.lblPadaria.Name = "lblPadaria";
            this.lblPadaria.Size = new System.Drawing.Size(216, 29);
            this.lblPadaria.TabIndex = 0;
            this.lblPadaria.Text = "Padaria Pão Fofo";
            // 
            // txtPao
            // 
            this.txtPao.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPao.Location = new System.Drawing.Point(163, 142);
            this.txtPao.Name = "txtPao";
            this.txtPao.Size = new System.Drawing.Size(394, 31);
            this.txtPao.TabIndex = 1;
            // 
            // lblPao
            // 
            this.lblPao.AutoSize = true;
            this.lblPao.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPao.Location = new System.Drawing.Point(158, 102);
            this.lblPao.Name = "lblPao";
            this.lblPao.Size = new System.Drawing.Size(399, 25);
            this.lblPao.TabIndex = 2;
            this.lblPao.Text = "Digite a quantidade de pães que deseja:";
            // 
            // pnlPadaria
            // 
            this.pnlPadaria.BackColor = System.Drawing.Color.LemonChiffon;
            this.pnlPadaria.Controls.Add(this.lblPadaria);
            this.pnlPadaria.Location = new System.Drawing.Point(-2, -1);
            this.pnlPadaria.Name = "pnlPadaria";
            this.pnlPadaria.Size = new System.Drawing.Size(804, 88);
            this.pnlPadaria.TabIndex = 3;
            // 
            // lblBroa
            // 
            this.lblBroa.AutoSize = true;
            this.lblBroa.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBroa.Location = new System.Drawing.Point(158, 188);
            this.lblBroa.Name = "lblBroa";
            this.lblBroa.Size = new System.Drawing.Size(408, 25);
            this.lblBroa.TabIndex = 4;
            this.lblBroa.Text = "Digite a quantidade de Broas que deseja:";
            // 
            // txtBroa
            // 
            this.txtBroa.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBroa.Location = new System.Drawing.Point(167, 225);
            this.txtBroa.Name = "txtBroa";
            this.txtBroa.Size = new System.Drawing.Size(389, 31);
            this.txtBroa.TabIndex = 5;
            // 
            // btnComprar
            // 
            this.btnComprar.BackColor = System.Drawing.Color.LightCoral;
            this.btnComprar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnComprar.Location = new System.Drawing.Point(224, 282);
            this.btnComprar.Name = "btnComprar";
            this.btnComprar.Size = new System.Drawing.Size(277, 83);
            this.btnComprar.TabIndex = 6;
            this.btnComprar.Text = "Comprar";
            this.btnComprar.UseVisualStyleBackColor = false;
            this.btnComprar.Click += new System.EventHandler(this.btnComprar_Click);
            // 
            // lblLegenda
            // 
            this.lblLegenda.AutoSize = true;
            this.lblLegenda.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLegenda.Location = new System.Drawing.Point(246, 384);
            this.lblLegenda.Name = "lblLegenda";
            this.lblLegenda.Size = new System.Drawing.Size(149, 25);
            this.lblLegenda.TabIndex = 7;
            this.lblLegenda.Text = "Valor a Pagar:";
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado.Location = new System.Drawing.Point(401, 384);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(46, 25);
            this.lblResultado.TabIndex = 8;
            this.lblResultado.Text = "R$-";
            // 
            // FrmQuestao01
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PeachPuff;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.lblLegenda);
            this.Controls.Add(this.btnComprar);
            this.Controls.Add(this.txtBroa);
            this.Controls.Add(this.lblBroa);
            this.Controls.Add(this.pnlPadaria);
            this.Controls.Add(this.lblPao);
            this.Controls.Add(this.txtPao);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmQuestao01";
            this.Text = "Padaria Pão Fofo";
            this.pnlPadaria.ResumeLayout(false);
            this.pnlPadaria.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPadaria;
        private System.Windows.Forms.TextBox txtPao;
        private System.Windows.Forms.Label lblPao;
        private System.Windows.Forms.Panel pnlPadaria;
        private System.Windows.Forms.Label lblBroa;
        private System.Windows.Forms.TextBox txtBroa;
        private System.Windows.Forms.Button btnComprar;
        private System.Windows.Forms.Label lblLegenda;
        private System.Windows.Forms.Label lblResultado;
    }
}


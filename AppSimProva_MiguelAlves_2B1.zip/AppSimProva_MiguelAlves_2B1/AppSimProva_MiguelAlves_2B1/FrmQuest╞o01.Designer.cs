﻿namespace AppSimProva_MiguelAlves_2B1
{
    partial class FrmQuestão01
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlTitulo = new System.Windows.Forms.Panel();
            this.pnlParc = new System.Windows.Forms.Panel();
            this.txtProd1 = new System.Windows.Forms.TextBox();
            this.txtProd2 = new System.Windows.Forms.TextBox();
            this.txtProd3 = new System.Windows.Forms.TextBox();
            this.lblProd1 = new System.Windows.Forms.Label();
            this.lblProd2 = new System.Windows.Forms.Label();
            this.lblProd3 = new System.Windows.Forms.Label();
            this.txtPreco1 = new System.Windows.Forms.TextBox();
            this.txtPreco3 = new System.Windows.Forms.TextBox();
            this.txtPreco2 = new System.Windows.Forms.TextBox();
            this.lblPreco1 = new System.Windows.Forms.Label();
            this.lblPreco2 = new System.Windows.Forms.Label();
            this.lblPreco3 = new System.Windows.Forms.Label();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.pnlResult = new System.Windows.Forms.Panel();
            this.lblParc1 = new System.Windows.Forms.Label();
            this.lblParc2 = new System.Windows.Forms.Label();
            this.lblParc3 = new System.Windows.Forms.Label();
            this.lblParc4 = new System.Windows.Forms.Label();
            this.lblParc5 = new System.Windows.Forms.Label();
            this.lblResult1 = new System.Windows.Forms.Label();
            this.lblResult2 = new System.Windows.Forms.Label();
            this.lblResult3 = new System.Windows.Forms.Label();
            this.lblResult4 = new System.Windows.Forms.Label();
            this.lblResult5 = new System.Windows.Forms.Label();
            this.btnComprar = new System.Windows.Forms.Button();
            this.pnlTitulo.SuspendLayout();
            this.pnlParc.SuspendLayout();
            this.pnlResult.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlTitulo
            // 
            this.pnlTitulo.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pnlTitulo.Controls.Add(this.lblTitulo);
            this.pnlTitulo.Location = new System.Drawing.Point(52, 24);
            this.pnlTitulo.Name = "pnlTitulo";
            this.pnlTitulo.Size = new System.Drawing.Size(698, 109);
            this.pnlTitulo.TabIndex = 0;
            // 
            // pnlParc
            // 
            this.pnlParc.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pnlParc.Controls.Add(this.lblPreco3);
            this.pnlParc.Controls.Add(this.lblPreco2);
            this.pnlParc.Controls.Add(this.lblPreco1);
            this.pnlParc.Controls.Add(this.txtPreco2);
            this.pnlParc.Controls.Add(this.txtPreco3);
            this.pnlParc.Controls.Add(this.txtPreco1);
            this.pnlParc.Controls.Add(this.lblProd3);
            this.pnlParc.Controls.Add(this.lblProd2);
            this.pnlParc.Controls.Add(this.lblProd1);
            this.pnlParc.Controls.Add(this.txtProd3);
            this.pnlParc.Controls.Add(this.txtProd2);
            this.pnlParc.Controls.Add(this.txtProd1);
            this.pnlParc.Location = new System.Drawing.Point(61, 165);
            this.pnlParc.Name = "pnlParc";
            this.pnlParc.Size = new System.Drawing.Size(349, 233);
            this.pnlParc.TabIndex = 1;
            // 
            // txtProd1
            // 
            this.txtProd1.Location = new System.Drawing.Point(19, 43);
            this.txtProd1.Name = "txtProd1";
            this.txtProd1.Size = new System.Drawing.Size(100, 20);
            this.txtProd1.TabIndex = 0;
            // 
            // txtProd2
            // 
            this.txtProd2.Location = new System.Drawing.Point(19, 91);
            this.txtProd2.Name = "txtProd2";
            this.txtProd2.Size = new System.Drawing.Size(100, 20);
            this.txtProd2.TabIndex = 1;
            // 
            // txtProd3
            // 
            this.txtProd3.Location = new System.Drawing.Point(19, 152);
            this.txtProd3.Name = "txtProd3";
            this.txtProd3.Size = new System.Drawing.Size(100, 20);
            this.txtProd3.TabIndex = 2;
            // 
            // lblProd1
            // 
            this.lblProd1.AutoSize = true;
            this.lblProd1.Location = new System.Drawing.Point(25, 18);
            this.lblProd1.Name = "lblProd1";
            this.lblProd1.Size = new System.Drawing.Size(53, 13);
            this.lblProd1.TabIndex = 3;
            this.lblProd1.Text = "Produto 1";
            // 
            // lblProd2
            // 
            this.lblProd2.AutoSize = true;
            this.lblProd2.Location = new System.Drawing.Point(25, 75);
            this.lblProd2.Name = "lblProd2";
            this.lblProd2.Size = new System.Drawing.Size(50, 13);
            this.lblProd2.TabIndex = 4;
            this.lblProd2.Text = "Produto2";
            // 
            // lblProd3
            // 
            this.lblProd3.AutoSize = true;
            this.lblProd3.Location = new System.Drawing.Point(25, 136);
            this.lblProd3.Name = "lblProd3";
            this.lblProd3.Size = new System.Drawing.Size(53, 13);
            this.lblProd3.TabIndex = 5;
            this.lblProd3.Text = "Produto 3";
            // 
            // txtPreco1
            // 
            this.txtPreco1.Location = new System.Drawing.Point(217, 43);
            this.txtPreco1.Name = "txtPreco1";
            this.txtPreco1.Size = new System.Drawing.Size(100, 20);
            this.txtPreco1.TabIndex = 6;
            // 
            // txtPreco3
            // 
            this.txtPreco3.Location = new System.Drawing.Point(217, 152);
            this.txtPreco3.Name = "txtPreco3";
            this.txtPreco3.Size = new System.Drawing.Size(100, 20);
            this.txtPreco3.TabIndex = 8;
            // 
            // txtPreco2
            // 
            this.txtPreco2.Location = new System.Drawing.Point(217, 91);
            this.txtPreco2.Name = "txtPreco2";
            this.txtPreco2.Size = new System.Drawing.Size(100, 20);
            this.txtPreco2.TabIndex = 9;
            // 
            // lblPreco1
            // 
            this.lblPreco1.AutoSize = true;
            this.lblPreco1.Location = new System.Drawing.Point(223, 18);
            this.lblPreco1.Name = "lblPreco1";
            this.lblPreco1.Size = new System.Drawing.Size(44, 13);
            this.lblPreco1.TabIndex = 10;
            this.lblPreco1.Text = "Preço 1";
            // 
            // lblPreco2
            // 
            this.lblPreco2.AutoSize = true;
            this.lblPreco2.Location = new System.Drawing.Point(214, 75);
            this.lblPreco2.Name = "lblPreco2";
            this.lblPreco2.Size = new System.Drawing.Size(44, 13);
            this.lblPreco2.TabIndex = 11;
            this.lblPreco2.Text = "Preço 2";
            // 
            // lblPreco3
            // 
            this.lblPreco3.AutoSize = true;
            this.lblPreco3.Location = new System.Drawing.Point(214, 131);
            this.lblPreco3.Name = "lblPreco3";
            this.lblPreco3.Size = new System.Drawing.Size(44, 13);
            this.lblPreco3.TabIndex = 12;
            this.lblPreco3.Text = "Preço 3";
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblTitulo.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.lblTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(52, 40);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(125, 25);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Loja seu Zé";
            // 
            // pnlResult
            // 
            this.pnlResult.BackColor = System.Drawing.SystemColors.ControlDark;
            this.pnlResult.Controls.Add(this.btnComprar);
            this.pnlResult.Controls.Add(this.lblResult5);
            this.pnlResult.Controls.Add(this.lblResult4);
            this.pnlResult.Controls.Add(this.lblResult3);
            this.pnlResult.Controls.Add(this.lblResult2);
            this.pnlResult.Controls.Add(this.lblResult1);
            this.pnlResult.Controls.Add(this.lblParc5);
            this.pnlResult.Controls.Add(this.lblParc4);
            this.pnlResult.Controls.Add(this.lblParc3);
            this.pnlResult.Controls.Add(this.lblParc2);
            this.pnlResult.Controls.Add(this.lblParc1);
            this.pnlResult.Location = new System.Drawing.Point(445, 146);
            this.pnlResult.Name = "pnlResult";
            this.pnlResult.Size = new System.Drawing.Size(321, 292);
            this.pnlResult.TabIndex = 2;
            // 
            // lblParc1
            // 
            this.lblParc1.AutoSize = true;
            this.lblParc1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParc1.Location = new System.Drawing.Point(28, 19);
            this.lblParc1.Name = "lblParc1";
            this.lblParc1.Size = new System.Drawing.Size(109, 20);
            this.lblParc1.TabIndex = 0;
            this.lblParc1.Text = "01 parcela de:";
            // 
            // lblParc2
            // 
            this.lblParc2.AutoSize = true;
            this.lblParc2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParc2.Location = new System.Drawing.Point(28, 50);
            this.lblParc2.Name = "lblParc2";
            this.lblParc2.Size = new System.Drawing.Size(109, 20);
            this.lblParc2.TabIndex = 1;
            this.lblParc2.Text = "02 parcela de:";
            // 
            // lblParc3
            // 
            this.lblParc3.AutoSize = true;
            this.lblParc3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParc3.Location = new System.Drawing.Point(28, 87);
            this.lblParc3.Name = "lblParc3";
            this.lblParc3.Size = new System.Drawing.Size(109, 20);
            this.lblParc3.TabIndex = 2;
            this.lblParc3.Text = "03 parcela de:";
            // 
            // lblParc4
            // 
            this.lblParc4.AutoSize = true;
            this.lblParc4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParc4.Location = new System.Drawing.Point(28, 122);
            this.lblParc4.Name = "lblParc4";
            this.lblParc4.Size = new System.Drawing.Size(109, 20);
            this.lblParc4.TabIndex = 3;
            this.lblParc4.Text = "04 parcela de:";
            // 
            // lblParc5
            // 
            this.lblParc5.AutoSize = true;
            this.lblParc5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParc5.Location = new System.Drawing.Point(28, 155);
            this.lblParc5.Name = "lblParc5";
            this.lblParc5.Size = new System.Drawing.Size(109, 20);
            this.lblParc5.TabIndex = 4;
            this.lblParc5.Text = "05 parcela de:";
            // 
            // lblResult1
            // 
            this.lblResult1.AutoSize = true;
            this.lblResult1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResult1.Location = new System.Drawing.Point(153, 19);
            this.lblResult1.Name = "lblResult1";
            this.lblResult1.Size = new System.Drawing.Size(14, 20);
            this.lblResult1.TabIndex = 5;
            this.lblResult1.Text = "-";
            // 
            // lblResult2
            // 
            this.lblResult2.AutoSize = true;
            this.lblResult2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResult2.Location = new System.Drawing.Point(153, 50);
            this.lblResult2.Name = "lblResult2";
            this.lblResult2.Size = new System.Drawing.Size(14, 20);
            this.lblResult2.TabIndex = 6;
            this.lblResult2.Text = "-";
            // 
            // lblResult3
            // 
            this.lblResult3.AutoSize = true;
            this.lblResult3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResult3.Location = new System.Drawing.Point(153, 89);
            this.lblResult3.Name = "lblResult3";
            this.lblResult3.Size = new System.Drawing.Size(14, 20);
            this.lblResult3.TabIndex = 7;
            this.lblResult3.Text = "-";
            // 
            // lblResult4
            // 
            this.lblResult4.AutoSize = true;
            this.lblResult4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResult4.Location = new System.Drawing.Point(153, 122);
            this.lblResult4.Name = "lblResult4";
            this.lblResult4.Size = new System.Drawing.Size(14, 20);
            this.lblResult4.TabIndex = 8;
            this.lblResult4.Text = "-";
            // 
            // lblResult5
            // 
            this.lblResult5.AutoSize = true;
            this.lblResult5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResult5.Location = new System.Drawing.Point(153, 155);
            this.lblResult5.Name = "lblResult5";
            this.lblResult5.Size = new System.Drawing.Size(14, 20);
            this.lblResult5.TabIndex = 9;
            this.lblResult5.Text = "-";
            // 
            // btnComprar
            // 
            this.btnComprar.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnComprar.Location = new System.Drawing.Point(29, 214);
            this.btnComprar.Name = "btnComprar";
            this.btnComprar.Size = new System.Drawing.Size(153, 56);
            this.btnComprar.TabIndex = 10;
            this.btnComprar.Text = "Calcular";
            this.btnComprar.UseVisualStyleBackColor = false;
            this.btnComprar.Click += new System.EventHandler(this.btnComprar_Click);
            // 
            // FrmQuestão01
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Aquamarine;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pnlResult);
            this.Controls.Add(this.pnlParc);
            this.Controls.Add(this.pnlTitulo);
            this.Name = "FrmQuestão01";
            this.Text = "Loja Seu Zé";
            this.pnlTitulo.ResumeLayout(false);
            this.pnlTitulo.PerformLayout();
            this.pnlParc.ResumeLayout(false);
            this.pnlParc.PerformLayout();
            this.pnlResult.ResumeLayout(false);
            this.pnlResult.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlTitulo;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Panel pnlParc;
        private System.Windows.Forms.Label lblPreco3;
        private System.Windows.Forms.Label lblPreco2;
        private System.Windows.Forms.Label lblPreco1;
        private System.Windows.Forms.TextBox txtPreco2;
        private System.Windows.Forms.TextBox txtPreco3;
        private System.Windows.Forms.TextBox txtPreco1;
        private System.Windows.Forms.Label lblProd3;
        private System.Windows.Forms.Label lblProd2;
        private System.Windows.Forms.Label lblProd1;
        private System.Windows.Forms.TextBox txtProd3;
        private System.Windows.Forms.TextBox txtProd2;
        private System.Windows.Forms.TextBox txtProd1;
        private System.Windows.Forms.Panel pnlResult;
        private System.Windows.Forms.Label lblResult5;
        private System.Windows.Forms.Label lblResult4;
        private System.Windows.Forms.Label lblResult3;
        private System.Windows.Forms.Label lblResult2;
        private System.Windows.Forms.Label lblResult1;
        private System.Windows.Forms.Label lblParc5;
        private System.Windows.Forms.Label lblParc4;
        private System.Windows.Forms.Label lblParc3;
        private System.Windows.Forms.Label lblParc2;
        private System.Windows.Forms.Label lblParc1;
        private System.Windows.Forms.Button btnComprar;
    }
}


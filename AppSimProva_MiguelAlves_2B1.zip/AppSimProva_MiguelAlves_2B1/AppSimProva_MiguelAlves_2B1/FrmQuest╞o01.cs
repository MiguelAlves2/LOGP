﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppSimProva_MiguelAlves_2B1
{
    public partial class FrmQuestão01 : Form
    {
        public FrmQuestão01()
        {
            InitializeComponent();
        }

        private void btnComprar_Click(object sender, EventArgs e)
        {
            float prod1 = float.Parse(txtPreco1.Text);
            float prod2 = float.Parse(txtPreco2.Text);
            float prod3 = float.Parse(txtPreco3.Text);
            float resultado;

            resultado = prod1 + prod2 + prod3;

            lblResult1.Text = (resultado / 1).ToString("C");
            lblResult2.Text = (resultado / 2).ToString("C");
            lblResult3.Text = (resultado / 3).ToString("C");
            lblResult4.Text = (resultado / 4).ToString("C");
            lblResult5.Text = (resultado / 5).ToString("C");

            
        }
    }
}
